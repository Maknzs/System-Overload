// Card.jsx
import "./Card.css";

export default function Card({
  name,
  src, // (optional) explicit image path if you’re mapping names → files elsewhere
  onClick,
  disabled = false,
  size = "hand", // 'hand' | 'discard' | 'deck'
}) {
  const classNames = [
    "card-img",
    `card-img--${size}`,
    disabled ? "is-disabled" : "",
    onClick && !disabled ? "is-clickable" : "",
  ]
    .filter(Boolean)
    .join(" ");

  // If you're deriving the image from `name`, keep that logic; `src` is just a way to override.
  const url = src || `/cards/${name}.png`;

  return (
    <img
      src={url}
      alt={name}
      className={classNames}
      onClick={disabled ? undefined : onClick}
      draggable={false}
    />
  );
}
